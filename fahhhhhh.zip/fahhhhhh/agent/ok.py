import numpy as np
import pandas as pd
import yfinance as yf
import ta
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from agent.find import get_price_history
from sklearn.model_selection import TimeSeriesSplit
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error
from statsmodels.tsa.arima.model import ARIMA
import warnings
warnings.filterwarnings('ignore')


window =10
def select_features(df, cols, target_col="target", top_n=12):
    correlations = df[cols].corrwith(df[target_col]).abs().sort_values(ascending=False)
    return correlations.head(top_n).index.tolist()

def feature(date, closes, volumes, low, high, horizon=1, index_df=None,news_df=None) -> pd.DataFrame:
    df = pd.DataFrame({"date": date, "Close": closes, "Volume": volumes, "Low": low, "High": high})

    df["return_1d"] = df["Close"].pct_change(1)
    df["return_3d"] = df["Close"].pct_change(3)
    df["return_5d"] = df["Close"].pct_change(5)
    df["return_10d"] = df["Close"].pct_change(10)

    df['ma5'] = df['Close'].rolling(5).mean()
    df['ma10'] = df['Close'].rolling(10).mean()
    df['ma20'] = df['Close'].rolling(20).mean()

    df["price_ma5"] = df["Close"] / df["ma5"]
    df["price_ma10"] = df["Close"] / df["ma10"]
    df["price_ma20"] = df["Close"] / df["ma20"]

    df['vol_5d'] = df['Close'].rolling(5).std()
    df['vol_20d'] = df['Close'].rolling(20).std()

    df["volume_change"] = df["Volume"].pct_change(1)
    df["volume_ma5"] = df["Volume"].rolling(5).mean()
    df["volume_vs_ma"] = df["Volume"] / df["volume_ma5"]

    df["RSI"] = ta.momentum.RSIIndicator(df["Close"]).rsi()
    df["MACD"] = ta.trend.MACD(df["Close"]).macd()
    df["ADX"] = ta.trend.ADXIndicator(df["High"], df["Low"], df["Close"]).adx()
    df["CCI"] = ta.trend.CCIIndicator(df["High"], df["Low"], df["Close"]).cci()
    df["ATR"] = ta.volatility.AverageTrueRange(df["High"], df["Low"], df["Close"]).average_true_range()

    bb = ta.volatility.BollingerBands(df["Close"])
    df["return_lag2"] = df["return_1d"].shift(2)
    df["return_lag3"] = df["return_1d"].shift(3)
    df["rsi_lag1"] = df["RSI"].shift(1)
    df["bb_high"] = bb.bollinger_hband()
    df["bb_low"] = bb.bollinger_lband()
    df["bb_width"] = bb.bollinger_wband()

    if index_df is not None:
        df = df.merge(index_df[["date", "index_return_1d"]], on="date", how="left")
        df["relative_return_1d"] = df["return_1d"] - df["index_return_1d"]

    if news_df is not None:
        df = df.merge(news_df[["date", "news_tone"]], on="date", how="left")
        df["news_tone"] = df["news_tone"].fillna(0)         
        df["news_tone_lag1"] = df["news_tone"].shift(1)  
    
    df["target"] = df["Close"].shift(-horizon) / df["Close"] - 1
    return df


def create_seq(X, y, close, window=10):
    Xs, ys, last_price = [], [], []
    for i in range(len(X) - window):
        Xs.append(X[i:i + window])
        ys.append(y[i + window])
        last_price.append(close[i + window - 1])  
    return np.array(Xs), np.array(ys), np.array(last_price)


feature_cols = ["Close", "return_1d", "return_3d", "return_5d", "return_10d",
                 "price_ma5", "price_ma10", "price_ma20",
                 "vol_5d", "vol_20d",
                 "RSI", "MACD", "ADX", "CCI", "ATR",
                 "volume_vs_ma", "bb_width", "rsi_lag1",
                 "return_lag2", "return_lag3"]


def diagnose_fit(X_tr, y_tr, lp_tr, X_val, y_val, X_test, y_test, models):
    def acc(X, y, models):
        with torch.no_grad():
            preds = np.mean([m(torch.FloatTensor(X)).numpy().flatten() for m in models], axis=0)
        return (np.sign(preds) == np.sign(y)).mean() * 100

    train_acc = acc(X_tr, y_tr, models)
    val_acc = acc(X_val, y_val, models)
    test_acc = acc(X_test, y_test, models)
    print(f"train_acc={train_acc:.1f}%  val_acc={val_acc:.1f}%  test_acc={test_acc:.1f}%")
    if train_acc - test_acc > 15:
        print("------ large train/test gap: overfitting")
    elif train_acc < 55 and val_acc < 55:
        print("------ model isn't learning much even on training data: underfitting, OR the signal genuinely isn't there")
    return train_acc, val_acc, test_acc

class LSTMmodel(nn.Module):
    def __init__(self, input_size, hidden_size=16, num_layers=1):
        super().__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.dropout = nn.Dropout(0.4)
        self.fc = nn.Linear(hidden_size, 1)

    def forward(self, x):
        out, _ = self.lstm(x)
        out = self.dropout(out[:, -1, :])
        return self.fc(out)


def directional_loss(pred, true, last_price, alpha=0.5):
    mse = nn.functional.mse_loss(pred, true)
    pred_dir = torch.tanh((pred - last_price) * 10)
    true_dir = torch.tanh((true - last_price) * 10)
    dir_penalty = torch.mean((pred_dir - true_dir) ** 2)
    return (1 - alpha) * mse + alpha * dir_penalty

def _train(X_seq,y_seq,lp_seq,input_size,n_seeds=3):
    val_cut = max(int(len(X_seq)*0.85),1)
    X_tr, y_tr, lp_tr = X_seq[:val_cut], y_seq[:val_cut], lp_seq[:val_cut]
    X_val, y_val, lp_val = X_seq[val_cut:], y_seq[val_cut:], lp_seq[val_cut:]
 
    models = []
    for seed in range(n_seeds):
        torch.manual_seed(seed)
        model =LSTMmodel(input_size, hidden_size=32,num_layers=2)
        optimiser = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=5e-3)
 
        X_t = torch.FloatTensor(X_tr)
        y_t = torch.FloatTensor(y_tr).unsqueeze(1)
        lp_t = torch.FloatTensor(lp_tr).unsqueeze(1)
        loader = DataLoader(TensorDataset(X_t, y_t, lp_t), batch_size=16, shuffle=False)
 
        X_val_t = torch.FloatTensor(X_val)
        y_val_t = torch.FloatTensor(y_val).unsqueeze(1)
        lp_val_t = torch.FloatTensor(lp_val).unsqueeze(1)
 
        best_val_loss = float("inf")
        best_state = None
        patience, patience_left = 8, 8
        
        for epoch in range(60):
            model.train()
            for xb, yb, lpb in loader:
                optimiser.zero_grad()
                loss = directional_loss(model(xb), yb, lpb)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimiser.step()
 
            model.eval()
            with torch.no_grad():
                val_loss = directional_loss(model(X_val_t), y_val_t, lp_val_t).item() if len(X_val) > 0 else loss.item()
 
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
                patience_left = patience
            else:
                patience_left -= 1
                if patience_left <= 0:
                    break
        if best_state is not None:
            model.load_state_dict(best_state)
        model.eval()
        models.append(model)
 
    return models



def dir_acc(df,cols,n_splits=3):
    X_raw = df[cols].values
    y_raw = df["target"].values
    close_raw = df["Close"].values
    
    
    tscv = TimeSeriesSplit(n_splits=n_splits)
    fold_accs = []

    for fold, (train_idx, test_idx) in enumerate(tscv.split(X_raw)):
        X_train_raw, X_test_raw = X_raw[train_idx], X_raw[test_idx]
        y_train_raw, y_test_raw = y_raw[train_idx], y_raw[test_idx]
        close_train, close_test = close_raw[train_idx], close_raw[test_idx]

        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train_raw)
        X_test_scaled = scaler.transform(X_test_raw)

        y_scaler = StandardScaler()
        y_train_scaled = y_scaler.fit_transform(y_train_raw.reshape(-1, 1)).flatten()


        X_train_seq, y_train_seq, train_last_price = create_seq(X_train_scaled, y_train_scaled, close_train, window)
        X_test_seq, y_test_seq, last_known_price = create_seq(X_test_scaled, y_test_raw, close_test, window)

        train_last_price_scaled = np.zeros_like(train_last_price, dtype=float)  
        # last_known_price = close_test[window:window + len(y_test_seq)]
        
        if len(X_train_seq) < 20 or len(X_test_seq) == 0:
            continue
 
        lp_scaled = np.zeros_like(train_last_price, dtype=float)
        models = _train(X_train_seq, y_train_seq, lp_scaled, input_size=len(cols))
        val_cut = max(int(len(X_train_seq) * 0.85), 1)   # same split _train() uses internally
        diagnose_fit(X_train_seq[:val_cut], y_train_seq[:val_cut],
                     None,
                     X_train_seq[val_cut:], y_train_seq[val_cut:],
                     X_test_seq, y_test_seq, models)
        with torch.no_grad():
            X_test_t = torch.FloatTensor(X_test_seq)
            preds = np.mean([m(X_test_t).numpy().flatten() for m in models], axis=0)
        preds_return = y_scaler.inverse_transform(preds.reshape(-1, 1)).flatten()
 
        direction_acc = (np.sign(preds_return) == np.sign(y_test_seq)).mean() * 100
        fold_accs.append(direction_acc)
 
    return round(float(np.mean(fold_accs)), 1) if fold_accs else None

def train_multi_stock(stocks, period="3y", horizon=21, test_frac=0.15):
    index_hist = get_price_history("^NSEI", period)
    index_df = pd.DataFrame({
        "date": index_hist["dates"],
        "index_return_1d": pd.Series(index_hist["close"]).pct_change(1),
    })

    all_train_X, all_train_y, all_train_lp = [], [], []
    test_sets = {}
    cols = None

    for sname in stocks:
        hist = get_price_history(sname, period)
        df = feature(hist["dates"], hist["close"], hist["volume"], hist["low"], hist["high"], horizon, index_df)

        stock_cols = feature_cols.copy()
        if "Close" in stock_cols:
            stock_cols.remove("Close")
        if "relative_return_1d" in df.columns:
            stock_cols.append("relative_return_1d")
        cols = stock_cols

        df = df.replace([np.inf, -np.inf], np.nan).dropna().reset_index(drop=True)
        if len(df) < window + 40:
            print(f"skipping {sname}, not enough data")
            continue

        split = int(len(df) * (1 - test_frac))
        train_df, test_df = df.iloc[:split], df.iloc[split:]

        X_train_raw, y_train_raw, close_train = train_df[cols].values, train_df["target"].values, train_df["Close"].values
        X_test_raw, y_test_raw, close_test = test_df[cols].values, test_df["target"].values, test_df["Close"].values

        scaler = StandardScaler().fit(X_train_raw)
        X_train_scaled, X_test_scaled = scaler.transform(X_train_raw), scaler.transform(X_test_raw)

        y_scaler = StandardScaler().fit(y_train_raw.reshape(-1, 1))
        y_train_scaled = y_scaler.transform(y_train_raw.reshape(-1, 1)).flatten()

        X_train_seq, y_train_seq, train_lp = create_seq(X_train_scaled, y_train_scaled, close_train, window)
        X_test_seq, y_test_seq, _ = create_seq(X_test_scaled, y_test_raw, close_test, window)

        if len(X_train_seq) < 20 or len(X_test_seq) == 0:
            continue

        all_train_X.append(X_train_seq)
        all_train_y.append(y_train_seq)
        all_train_lp.append(np.zeros_like(train_lp, dtype=float))
        test_sets[sname] = (X_test_seq, y_test_seq, y_scaler)

    X_train_all = np.concatenate(all_train_X, axis=0)
    y_train_all = np.concatenate(all_train_y, axis=0)
    lp_train_all = np.concatenate(all_train_lp, axis=0)

    print(f"Training on {len(X_train_all)} pooled sequences from {len(test_sets)} stocks")
    models = _train(X_train_all, y_train_all, lp_train_all, input_size=len(cols))

    print(f"\nhorizon={horizon} ")
    accs = []
    for sname, (X_test_seq, y_test_seq, y_scaler) in test_sets.items():
        with torch.no_grad():
            preds_scaled = np.mean([m(torch.FloatTensor(X_test_seq)).numpy().flatten() for m in models], axis=0)
        preds_return = y_scaler.inverse_transform(preds_scaled.reshape(-1, 1)).flatten()
        acc = (np.sign(preds_return) == np.sign(y_test_seq)).mean() * 100
        accs.append(acc)
        print(f"{sname}: direction_acc={acc:.1f}%  (n={len(y_test_seq)})")

    print(f"\nAverage across stocks: {np.mean(accs):.1f}%")
    return accs


def per_stock_backtest(stocks, period="3y", horizon=21):
    index_hist = get_price_history("^NSEI", period)
    index_df = pd.DataFrame({
        "date": index_hist["dates"],
        "index_return_1d": pd.Series(index_hist["close"]).pct_change(1),
    })

    results = {}
    for sname in stocks:
        try:
            hist = get_price_history(sname, period)
            df = feature(hist["dates"], hist["close"], hist["volume"], hist["low"], hist["high"], horizon, index_df)
            cols = feature_cols.copy()
            if "relative_return_1d" in df.columns:
                cols.append("relative_return_1d")
            df = df.replace([np.inf, -np.inf], np.nan).dropna().reset_index(drop=True)
            if len(df) < window + 40:
                print(f"{sname}: skipped, not enough data")
                continue
            acc = dir_acc(df, cols)
            results[sname] = acc
            print(f"{sname}: backtested_direction_acc={acc}%")
        except Exception as e:
            print(f"{sname}: failed - {e}")

    valid = [v for v in results.values() if v is not None]
    if valid:
        print(f"\nAverage across {len(valid)} stocks: {np.mean(valid):.1f}%")
        print(f"Range: {min(valid):.1f}% to {max(valid):.1f}%")
    return results


if __name__ == "__main__":
    stocks = [
        "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "ICICIBANK.NS",
        "HINDUNILVR.NS", "ITC.NS", "SBIN.NS", "BHARTIARTL.NS", "KOTAKBANK.NS",
        "WIPRO.NS", "HCLTECH.NS", "TECHM.NS", "PERSISTENT.NS", "COFORGE.NS", "LTIM.NS",
        "AXISBANK.NS", "INDUSINDBK.NS", "BAJFINANCE.NS", "BAJAJFINSV.NS","IDFCFIRSTB.NS", "FEDERALBNK.NS",
        "SUNPHARMA.NS", "DRREDDY.NS", "CIPLA.NS", "DIVISLAB.NS", "LUPIN.NS", "AUROPHARMA.NS",
        "MARUTI.NS", "TATAMOTORS.NS", "M&M.NS", "BAJAJ-AUTO.NS", "EICHERMOT.NS", "BOSCHLTD.NS",
        "NESTLEIND.NS", "BRITANNIA.NS", "DABUR.NS", "GODREJCP.NS", "MARICO.NS", "TATACONSUM.NS",
        "ONGC.NS", "NTPC.NS", "POWERGRID.NS", "ADANIPOWER.NS", "TATAPOWER.NS", "COALINDIA.NS",
        "TATASTEEL.NS", "JSWSTEEL.NS", "HINDALCO.NS", "VEDL.NS", "JINDALSTEL.NS",
        "DEEPAKNTR.NS", "SRF.NS", "PIIND.NS", "AARTIIND.NS", "NAVINFLUOR.NS",
        "ULTRACEMCO.NS", "SHREECEM.NS", "GRASIM.NS", "LT.NS", "ACC.NS", "IDEA.NS", "ZEEL.NS",
    "DLF.NS", "GODREJPROP.NS", "OBEROIRLTY.NS",
]
    per_stock_backtest(stocks, horizon=21)
        
        

    
    
    
    
    
    
    
    
    
    
# def lstm_walk(sname, period="3y", horizons=(1, 5, 21)):
#     hist = get_price_history(sname, period)
#     index_hist = get_price_history("^NSEI", period)
#     index_df = pd.DataFrame({
#         "date": index_hist["dates"],
#         "index_return_1d": pd.Series(index_hist['close']).pct_change(1),
#     })

#     horizon_labels = {1: "1-day", 5: "5-day (weekly)", 21: "21-day (~monthly)"}

#     for horizon in horizons:
#         print(horizon)
#         results = run_horizon(sname, horizon, hist, index_df)
#         for r in results:
#             print(f"fold {r['fold']}: test_mse={r['test_mse']:.2f}  naive_mse={r['naive_mse']:.2f}  "
#                   f"direction_acc={r['direction_acc']:.1f}%")

#         avg_direction = np.mean([r["direction_acc"] for r in results])
        
#         print(f"LSTM direction_acc: {avg_direction:.1f}% ")    